import java.io.IOException;

public interface StringListener{
    public void textEmitted(String text) throws IOException;
}